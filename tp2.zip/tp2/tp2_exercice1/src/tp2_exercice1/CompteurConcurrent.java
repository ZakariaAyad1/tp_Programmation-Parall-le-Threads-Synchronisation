package tp2_exercice1;

public class CompteurConcurrent {
	
	private int cpt = 0;

    public int getValue() { return cpt; }
    public String showMessage() { return "number found"; }

    synchronized public void increment() {
        cpt++;
    }

}
