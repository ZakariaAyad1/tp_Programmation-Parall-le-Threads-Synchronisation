package tp2_exercice1;

public class ConcurrentSearchTask implements Runnable{
	
	private static final int TAILLE_MIN = 10000;

    private final int[] array;
    private final int start;
    private final int end;
    private final int elementToFind;
    private final CompteurConcurrent counter;
    private final SearchStrategy strategy;
    
    public ConcurrentSearchTask(int[] array, int start, int end, int elementToFind, CompteurConcurrent counter, SearchStrategy strategy) {
        this.array = array;
        this.start = start;
        this.end = end;
        this.elementToFind = elementToFind;
        this.counter = counter;
        this.strategy = strategy;
    }
    
    

	@Override
	public void run() {
		int length = end - start;
		
		if (length > TAILLE_MIN) {
			int mid = start + length / 2;
			
			strategy.search(array, start, mid, elementToFind, counter);
			
			Runnable secondHalfTask = new ConcurrentSearchTask(
	                array, mid, end, elementToFind, counter, strategy
	            );
			
			Thread worker = new Thread(secondHalfTask);
            worker.start();
            
            try {
                worker.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Search interrupted: " + e.getMessage());
            }
			
			
		} else {
            strategy.search(array, start, end, elementToFind, counter);
        }

		
	}

}
