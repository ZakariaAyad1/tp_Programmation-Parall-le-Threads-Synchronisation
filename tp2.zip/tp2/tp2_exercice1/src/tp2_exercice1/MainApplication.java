package tp2_exercice1;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

public class MainApplication {
	private static final int ARRAY_SIZE = 2500000;
    private static final int ELEMENT_TO_FIND = 42;

    public static void main(String[] args) {
    	
    	int[] dataArray = createLargeArray(ARRAY_SIZE, ELEMENT_TO_FIND);
    	
    	int target = ELEMENT_TO_FIND;
    	
    	CompteurConcurrent concurrentCounter = new CompteurConcurrent();
    	SearchStrategy searchStrategy = new SimpleSearchStrategy();
    	
    	System.out.println("Starting concurrent search for element: " + target);
        long startTime = System.currentTimeMillis();
        
        ConcurrentSearchTask mainTask = new ConcurrentSearchTask(
                dataArray, 0, dataArray.length, target, concurrentCounter, searchStrategy
            );
        
        Thread mainWorker = new Thread(mainTask);
        mainWorker.start();
        
        try {
            mainWorker.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.err.println("Main search process interrupted.");
            return;
        }
        
        long endTime = System.currentTimeMillis();
        
        int finalCount = concurrentCounter.getValue();
        System.out.println("----------------------------------------");
        System.out.println("Search completed in: " + (endTime - startTime) + " ms");
        System.out.println("Total occurrences found: " + finalCount);
        
        int verificationCount = (int) Arrays.stream(dataArray).filter(x -> x == target).count();
        System.out.println("Verification count (sequential): " + verificationCount);
        System.out.println("Result Message: " + concurrentCounter.showMessage());

    	
    }

	private static int[] createLargeArray(int size, int element) {
		int[] array = new int[size];
        ThreadLocalRandom random = ThreadLocalRandom.current();
        
        for (int i = 0; i < size; i++) {
            if (random.nextInt(100) == 0) { // Approx 1% of the elements will be the target
                array[i] = element;
            } else {
                array[i] = random.nextInt(size);
            }
        }
        return array;
	}

}
