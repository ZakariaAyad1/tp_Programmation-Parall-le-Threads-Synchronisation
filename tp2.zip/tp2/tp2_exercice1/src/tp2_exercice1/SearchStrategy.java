package tp2_exercice1;

public interface SearchStrategy {
	
	void search(int[] array, int start, int end, int elementToFind, CompteurConcurrent counter);

}
