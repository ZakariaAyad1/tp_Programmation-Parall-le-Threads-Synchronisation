package tp2_exercice2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class MainApplication2 {
private static final int CHUNK_SIZE = 20; 
    
    private static final int ARRAY_SIZE = 100000; 
    private static final int ELEMENT_TO_FIND = 42;
    
    private static int[] createLargeArray(int size, int element) {
        int[] array = new int[size];
        ThreadLocalRandom random = ThreadLocalRandom.current();
        
        for (int i = 0; i < size; i++) {
            if (random.nextInt(100) == 0) { // Approx 1% occurrence
                array[i] = element;
            } else {
                array[i] = random.nextInt(size);
            }
        }
        return array;
    }
    
    public static void main(String[] args) {
    	int[] dataArray = createLargeArray(ARRAY_SIZE, ELEMENT_TO_FIND);
        int target = ELEMENT_TO_FIND;
        CompteurConcurrent concurrentCounter = new CompteurConcurrent();
        SearchStrategy searchStrategy = new SimpleSearchStrategy(); 
        
        List<Thread> workers = new ArrayList<>();

        long startTime = System.currentTimeMillis();
        int arrayLength = dataArray.length;
        
        for (int start = 0; start < arrayLength; start += CHUNK_SIZE) {
        	int end = Math.min(start + CHUNK_SIZE, arrayLength);
        	
        	Runnable task = new FixedSizeChunkSearchTask(
                    dataArray, start, end, target, concurrentCounter, searchStrategy
                );
        	
        	Thread worker = new Thread(task);
            workers.add(worker);
            worker.start();

        	
        }
        
        for (Thread worker : workers) {
            try {
                worker.join(); 
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Main search process interrupted.");
                return;
            }
        }
        
        long endTime = System.currentTimeMillis();
        
        int finalCount = concurrentCounter.getValue();
        System.out.println("----------------------------------------");
        System.out.println("Search completed in: " + (endTime - startTime) + " ms");
        System.out.println("Total occurrences found: " + finalCount);
        System.out.println("Number of threads created (M): " + workers.size());
        
        
        
        int verificationCount = (int) Arrays.stream(dataArray).filter(x -> x == target).count();
        System.out.println("Verification count (sequential): " + verificationCount);
        System.out.println("Result Message: " + concurrentCounter.showMessage());
    }

}
