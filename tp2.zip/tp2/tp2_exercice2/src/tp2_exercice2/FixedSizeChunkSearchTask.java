package tp2_exercice2;

public class FixedSizeChunkSearchTask implements Runnable{
	
	private final int[] array;
    private final int start;
    private final int end;
    private final int elementToFind;
    private final CompteurConcurrent counter;
    private final SearchStrategy strategy;

    public FixedSizeChunkSearchTask(int[] array, int start, int end, int elementToFind, CompteurConcurrent counter, SearchStrategy strategy) {
        this.array = array;
        this.start = start;
        this.end = end; 
        this.elementToFind = elementToFind;
        this.counter = counter;
        this.strategy = strategy;
    }
    

	@Override
	public void run() {
		strategy.search(array, start, end, elementToFind, counter);
		
	}

}
