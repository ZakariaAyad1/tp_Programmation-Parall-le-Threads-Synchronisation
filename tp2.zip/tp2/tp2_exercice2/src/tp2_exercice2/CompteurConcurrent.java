package tp2_exercice2;

public class CompteurConcurrent {
	
	private int cpt = 0;

    public int getValue() { return cpt; }
    public String showMessage() { return "number found"; }

    synchronized public void increment() {
        cpt++;
    }

}
