package tp2_exercice2;

public class SimpleSearchStrategy implements SearchStrategy{

	@Override
	public void search(int[] array, int start, int end, int elementToFind, CompteurConcurrent counter) {
		for (int i = start; i < end; i++) {
            if (array[i] == elementToFind) {
                // The increment method is synchronized in CompteurConcurrent, ensuring thread-safety.
                counter.increment();
            }
        }
		
	}

}
