package tp1_ex2;

public class Task implements Runnable {
	private String message;
    private int count;
    private long delay; // in milliseconds

    // Constructor for the tasks that need a message, count, and delay
    public Task(String message, int count, long delay) {
        this.message = message;
        this.count = count;
        this.delay = delay;
    }

    // Constructor for the simple "au revoir" task
    public Task(String message) {
        this(message, 1, 0); // Display once, no delay
    }
    
    
    @Override
    public void run() {
        System.out.println("Thread **" + Thread.currentThread().getName() + "** started.");
        try {
            for (int i = 0; i < count; i++) {
                // Display the message
                System.out.println(Thread.currentThread().getName() + ": " + message);

                // Pause the thread if a delay is specified
                if (delay > 0) {
                    Thread.sleep(delay); // Thread.sleep throws an InterruptedException
                }
            }
        } catch (InterruptedException e) {
            // Handle the case where the thread is interrupted while sleeping
            System.out.println(Thread.currentThread().getName() + " was interrupted.");
            Thread.currentThread().interrupt(); // Restore the interrupted status
        }
        System.out.println("Thread **" + Thread.currentThread().getName() + "** finished.");
    }
    
    

}
