package tp1_ex2;

public class Main {

	public static void main(String[] args) {
		// --- 1. First Thread: "Bonjour !" 10 times, 1-second delay (1000 ms)
        Task task1 = new Task("Bonjour !", 10, 1000);
        Thread thread1 = new Thread(task1, "Thread-Bonjour");

        // --- 2. Second Thread: "Salut !" 5 times, 2-second delay (2000 ms)
        Task task2 = new Task("Salut !", 5, 2000);
        Thread thread2 = new Thread(task2, "Thread-Salut");

        // --- 3. Third Thread: "au revoir" once, no delay
        Task task3 = new Task("au revoir");
        Thread thread3 = new Thread(task3, "Thread-AuRevoir");

        // Start all threads simultaneously
        thread1.start();
        thread2.start();
        thread3.start();

        System.out.println("Main thread finished starting all worker threads.");

	}

}
