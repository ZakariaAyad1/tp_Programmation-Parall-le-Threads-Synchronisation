/**
 * 
 */
/**
 * 
 */
module tp1 {
}