package tp1;

public class JavaApplictionTP1 extends Thread {
    private static int _cpt = 1;
    private String _name;

    public JavaApplictionTP1(String name) {
        _name = name;
    }

    public static int getValue() {
        return _cpt;
    }

    public void run() {
        for (int i = 1; i <= 10; i++) {
        	int _c;
            // Synchronisation sur la classe (car _cpt est statique)
            synchronized (JavaApplictionTP1.class) { 
                _c = _cpt++;
            }
            System.out.println(_c);
        }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("VALEUR avt : "+JavaApplictionTP1.getValue());
        JavaApplictionTP1 thr1 = new JavaApplictionTP1("Processus1");
        JavaApplictionTP1 thr2 = new JavaApplictionTP1("Processus2");

        thr1.start();//thr1.join();
        thr2.start();//thr2.join();

        System.out.println("VALEUR aps : "+JavaApplictionTP1.getValue());
    }
}




