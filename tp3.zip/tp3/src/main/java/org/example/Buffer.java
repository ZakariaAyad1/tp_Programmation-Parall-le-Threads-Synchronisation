package org.example;

import java.util.LinkedList;
import java.util.Queue;

public class Buffer {

    private final Queue<Integer> storage = new LinkedList<>();
    private final int capacity;


    public Buffer(int capacity) {
        this.capacity = capacity;
    }

    public void put(int value) throws InterruptedException {

        synchronized (storage) {
            while (storage.size() == capacity) {
                System.out.println("Buffer is FULL. Producer " + Thread.currentThread().getName() + " waits.");
                storage.wait();

            }

            storage.add(value);

            System.out.println("Producer " + Thread.currentThread().getName() + " produced: " + value + " | Size: " + storage.size());

            storage.notifyAll();

        }
    }

    public int take() throws InterruptedException {
        int value;

        synchronized (storage) {
            while(storage.isEmpty()) {
                System.out.println("Buffer is EMPTY. Consumer " + Thread.currentThread().getName() + " waits.");
                storage.wait();

            }

            value = storage.remove();
            System.out.println("Consumer " + Thread.currentThread().getName() + " consumed: " + value + " | Size: " + storage.size());

            storage.notifyAll();

        }

        return value;
    }
}
