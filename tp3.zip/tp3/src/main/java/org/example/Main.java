package org.example;

public class Main {
    public static void main(String[] args) {
        final int BUFFER_CAPACITY = 5;
        final int NUM_PRODUCERS = 3;
        final int NUM_CONSUMERS = 3;

        Buffer sharedBuffer = new Buffer(BUFFER_CAPACITY);

        for (int i = 1; i <= NUM_PRODUCERS; i++) {
            Thread producerThread = new Thread(new Producer(sharedBuffer), "Producer-" + i);
            producerThread.start();
        }

        for (int i = 1; i <= NUM_CONSUMERS; i++) {
            Thread consumerThread = new Thread(new Consumer(sharedBuffer), "Consumer-" + i);
            consumerThread.start();
        }

        System.out.println("Producer-Consumer system started with " + NUM_PRODUCERS +
                " producers and " + NUM_CONSUMERS + " consumers (Capacity: " + BUFFER_CAPACITY + ").");



    }
}