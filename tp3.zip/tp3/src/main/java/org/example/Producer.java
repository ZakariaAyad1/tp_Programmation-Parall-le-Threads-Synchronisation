package org.example;

public class Producer implements Runnable{

    private final Buffer buffer;
    private int producedCount = 0;

    public Producer(Buffer buffer) {
        this.buffer = buffer;
    }

    @Override
    public void run() {
        while (true) {
            try {
                int item = producedCount++;

                Thread.sleep(500);
                buffer.put(item);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println(Thread.currentThread().getName() + " interrupted and stopping.");
                break;
            }

        }

    }
}

